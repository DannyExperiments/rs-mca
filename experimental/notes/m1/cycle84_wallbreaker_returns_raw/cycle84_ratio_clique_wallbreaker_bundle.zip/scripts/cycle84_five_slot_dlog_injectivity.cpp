// Cycle 84 exact five-slot product-injectivity checker.
//
// Input: cycle84_ratio_atoms.csv emitted and arithmetically verified by
// cycle84_ratio_signature_instance.cpp.  For each slot t, the rows containing
// endpoint pair a:0 recover log_g(u_t(a)/u_t(0)).  The checker verifies every
// endpoint-pair ratio in the CSV against those recovered logs.
//
// For each requested five-slot subset it enumerates all 48^5 modular log sums.
// Equality of products implies equality of the 66-bit sum modulo N.  Sums are
// bucketed by the top byte of their low 64 bits and sorted.  A repeated low-64
// projection triggers an exact 66-bit fallback; hence a pass is deterministic
// and proof-safe, not probabilistic.
//
// Build: g++ -O3 -march=native -fopenmp -std=c++20 this.cpp -o checker
// Run all: checker cycle84_ratio_atoms.csv --all certificate.json
// Run one: checker cycle84_ratio_atoms.csv --subset 1,2,3,4,5 certificate.json

#include <algorithm>
#include <array>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <unordered_set>
#include <utility>
#include <vector>
#include <omp.h>

using u128 = unsigned __int128;
static constexpr u128 N = ((u128)4866119187566686848ULL) * 10U;
static constexpr uint64_t TUPLES = 48ULL*48*48*48*48;

static std::string dec(u128 x) {
    if (!x) return "0";
    std::string s;
    while (x) { s.push_back(char('0' + unsigned(x % 10))); x /= 10; }
    std::reverse(s.begin(), s.end());
    return s;
}
static u128 parse_u128(const std::string& s) {
    if (s.empty()) throw std::runtime_error("empty integer");
    u128 x=0;
    for(char c:s){ if(c<'0'||c>'9') throw std::runtime_error("bad integer"); x=x*10+unsigned(c-'0'); }
    return x;
}
static inline u128 addmod(u128 a, u128 b) {
    u128 z=a+b;
    if(z>=N) z-=N;
    return z;
}
static inline u128 submod(u128 a, u128 b) { return a>=b ? a-b : a+N-b; }

static std::vector<std::string> csv_fields(const std::string& line) {
    std::vector<std::string> out; std::string cur; bool quote=false;
    for(size_t i=0;i<line.size();++i){
        char c=line[i];
        if(c=='"') quote=!quote;
        else if(c==',' && !quote){ out.push_back(cur); cur.clear(); }
        else cur.push_back(c);
    }
    out.push_back(cur);
    if(quote) throw std::runtime_error("unterminated CSV quote");
    return out;
}

struct Atom { u128 e{}; std::vector<std::pair<int,int>> pairs; };
struct Result {
    std::array<int,5> slots{};
    uint64_t low64_duplicate_values{};
    uint64_t exact_duplicate_values{};
    bool injective{};
    double enumerate_seconds{}, sort_seconds{}, fallback_seconds{};
};

static std::array<std::vector<Atom>,7> read_atoms(const std::string& path,
                                                  u128 rel[7][48]) {
    std::ifstream in(path);
    if(!in) throw std::runtime_error("cannot open atom CSV");
    std::string line;
    if(!std::getline(in,line) || line.rfind("slot,atom_id,dlog",0)!=0)
        throw std::runtime_error("bad atom CSV header");
    std::array<std::vector<Atom>,7> atoms;
    while(std::getline(in,line)){
        if(line.empty()) continue;
        auto f=csv_fields(line);
        if(f.size()!=9) throw std::runtime_error("bad atom CSV field count");
        int t=std::stoi(f[0]);
        if(t<1||t>7) throw std::runtime_error("bad slot");
        Atom a; a.e=parse_u128(f[2]);
        std::stringstream ss(f[8]); std::string p;
        while(std::getline(ss,p,';')){
            auto k=p.find(':'); if(k==std::string::npos) throw std::runtime_error("bad endpoint pair");
            int x=std::stoi(p.substr(0,k)), y=std::stoi(p.substr(k+1));
            if(x<0||x>=48||y<0||y>=48) throw std::runtime_error("endpoint out of range");
            a.pairs.push_back({x,y});
        }
        atoms[t-1].push_back(std::move(a));
    }
    for(int t=0;t<7;++t){
        if(atoms[t].size()!=1153) throw std::runtime_error("atom count !=1153");
        std::array<bool,48> got{};
        for(const auto& a:atoms[t]) for(auto [x,y]:a.pairs) if(y==0){
            if(got[x] && rel[t][x]!=a.e) throw std::runtime_error("inconsistent relative log");
            rel[t][x]=a.e; got[x]=true;
        }
        for(bool b:got) if(!b) throw std::runtime_error("missing a:0 relative log");
        if(rel[t][0]!=0) throw std::runtime_error("base relative log nonzero");
        for(const auto& a:atoms[t]) for(auto [x,y]:a.pairs)
            if(submod(rel[t][x],rel[t][y])!=a.e)
                throw std::runtime_error("endpoint ratio/log verification failed");
    }
    return atoms;
}

static Result check_subset(const std::array<int,5>& one_based, const u128 rel[7][48]) {
    Result R; R.slots=one_based;
    int s[5]; for(int i=0;i<5;++i) s[i]=one_based[i]-1;
    constexpr size_t NA=48ULL*48*48, NB=48ULL*48, TOT=NA*NB;
    static_assert(TOT==TUPLES);
    std::vector<u128> A(NA), B(NB);
    size_t z=0;
    for(int a=0;a<48;++a) for(int b=0;b<48;++b) for(int c=0;c<48;++c)
        A[z++]=addmod(addmod(rel[s[0]][a],rel[s[1]][b]),rel[s[2]][c]);
    z=0;
    for(int a=0;a<48;++a) for(int b=0;b<48;++b)
        B[z++]=addmod(rel[s[3]][a],rel[s[4]][b]);

    int nt=omp_get_max_threads();
    std::vector<std::array<uint64_t,256>> cnt(nt); for(auto&x:cnt)x.fill(0);
    auto t0=std::chrono::steady_clock::now();
#pragma omp parallel
    {
        int tid=omp_get_thread_num(); auto& cc=cnt[tid];
#pragma omp for schedule(static)
        for(size_t i=0;i<NA;++i){
            u128 x=A[i];
            for(size_t j=0;j<NB;++j){u128 q=addmod(x,B[j]);uint64_t lo=(uint64_t)q;++cc[lo>>56];}
        }
    }
    std::array<uint64_t,257> start{};
    for(int b=0;b<256;++b){uint64_t c=0;for(int t=0;t<nt;++t)c+=cnt[t][b];start[b+1]=start[b]+c;}
    if(start[256]!=TOT) throw std::runtime_error("enumeration count mismatch");
    std::vector<std::array<uint64_t,256>> off(nt);
    for(int b=0;b<256;++b){uint64_t p=start[b];for(int t=0;t<nt;++t){off[t][b]=p;p+=cnt[t][b];}}
    std::vector<uint64_t> vals(TOT);
#pragma omp parallel
    {
        int tid=omp_get_thread_num(); auto oo=off[tid];
#pragma omp for schedule(static)
        for(size_t i=0;i<NA;++i){
            u128 x=A[i];
            for(size_t j=0;j<NB;++j){u128 q=addmod(x,B[j]);uint64_t lo=(uint64_t)q;int b=int(lo>>56);vals[oo[b]++]=lo;}
        }
    }
    auto t1=std::chrono::steady_clock::now();
    std::array<std::vector<uint64_t>,256> local_dups;
#pragma omp parallel for schedule(dynamic,1)
    for(int b=0;b<256;++b){
        auto beg=vals.begin()+start[b], end=vals.begin()+start[b+1];
        std::sort(beg,end);
        for(auto it=beg+1;it<end;++it) if(*it==*(it-1) && (local_dups[b].empty()||local_dups[b].back()!=*it))
            local_dups[b].push_back(*it);
    }
    std::unordered_set<uint64_t> dup_lo;
    for(auto&v:local_dups) for(uint64_t x:v) dup_lo.insert(x);
    R.low64_duplicate_values=dup_lo.size();
    auto t2=std::chrono::steady_clock::now();

    if(!dup_lo.empty()){
        // Exact 66-bit fallback.  A true duplicate has equal low64 and equal high bits.
        std::map<std::pair<uint16_t,uint64_t>,std::pair<uint64_t,uint64_t>> seen;
        std::set<std::pair<uint16_t,uint64_t>> exact_dups;
        for(size_t i=0;i<NA;++i) for(size_t j=0;j<NB;++j){
            u128 q=addmod(A[i],B[j]); uint64_t lo=(uint64_t)q;
            if(!dup_lo.count(lo)) continue;
            uint16_t hi=uint16_t(q>>64); auto key=std::make_pair(hi,lo);
            uint64_t code=i*NB+j;
            auto [it,ins]=seen.emplace(key,std::make_pair(code,code));
            if(!ins){it->second.second=code;exact_dups.insert(key);}
        }
        R.exact_duplicate_values=exact_dups.size();
    }
    auto t3=std::chrono::steady_clock::now();
    R.injective=(R.exact_duplicate_values==0);
    R.enumerate_seconds=std::chrono::duration<double>(t1-t0).count();
    R.sort_seconds=std::chrono::duration<double>(t2-t1).count();
    R.fallback_seconds=std::chrono::duration<double>(t3-t2).count();
    return R;
}

static std::array<int,5> parse_subset(const std::string& s){
    std::array<int,5> a{}; std::stringstream ss(s); std::string x; int i=0;
    while(std::getline(ss,x,',')){if(i>=5)throw std::runtime_error("too many subset entries");a[i++]=std::stoi(x);}
    if(i!=5)throw std::runtime_error("subset needs five entries");
    auto b=a;std::sort(b.begin(),b.end());
    for(int j=0;j<5;++j)if(b[j]<1||b[j]>7||(j&&b[j]==b[j-1]))throw std::runtime_error("bad subset");
    return b;
}

int main(int argc,char**argv){
    try{
        const bool all_mode = (argc==4 && std::string(argv[2])=="--all");
        const bool subset_mode = (argc==5 && std::string(argv[2])=="--subset");
        if(!all_mode && !subset_mode){
            std::cerr<<"usage: checker ATOMS.csv --all OUT.json\n"
                     <<"   or: checker ATOMS.csv --subset 1,2,3,4,5 OUT.json\n"; return 2;
        }
        const char* out_path = all_mode ? argv[3] : argv[4];
        u128 rel[7][48]{}; auto atoms=read_atoms(argv[1],rel); (void)atoms;
        std::vector<std::array<int,5>> subsets;
        if(subset_mode) subsets.push_back(parse_subset(argv[3]));
        else for(int a=1;a<=3;++a)for(int b=a+1;b<=4;++b)for(int c=b+1;c<=5;++c)for(int d=c+1;d<=6;++d)for(int e=d+1;e<=7;++e)subsets.push_back({a,b,c,d,e});
        std::vector<Result> results; bool ok=true;
        for(auto s:subsets){auto r=check_subset(s,rel);ok&=r.injective;results.push_back(r);std::cerr<<"checked";for(int x:s)std::cerr<<' '<<x;std::cerr<<" injective="<<r.injective<<"\n";if(!ok)break;}
        std::ostringstream js;
        js<<"{\n  \"decision\": \""<<(ok&&subsets.size()==21?"ALL_5_SUBSETS_PRODUCT_INJECTIVE":ok?"REQUESTED_5_SUBSETS_PRODUCT_INJECTIVE":"FIVE_SLOT_PRODUCT_COLLISION_FOUND")<<"\",\n";
        js<<"  \"field_order_minus_one\": \""<<dec(N)<<"\",\n";
        js<<"  \"input_ratio_atoms\": \""<<argv[1]<<"\",\n";
        js<<"  \"relative_log_endpoint_checks\": "<<7*48*48<<",\n";
        js<<"  \"projection\": \"low64_of_exact_dlog_sum_with_exact_66bit_fallback\",\n";
        js<<"  \"tuple_count_per_subset\": "<<TUPLES<<",\n";
        js<<"  \"subsets_checked\": "<<results.size()<<",\n  \"results\": [\n";
        for(size_t i=0;i<results.size();++i){auto&r=results[i];js<<"    {\"slots\": [";for(int j=0;j<5;++j){if(j)js<<',';js<<r.slots[j];}js<<"], \"injective\": "<<(r.injective?"true":"false")<<", \"low64_duplicate_values\": "<<r.low64_duplicate_values<<", \"exact_duplicate_values\": "<<r.exact_duplicate_values<<"}"<<(i+1<results.size()?",":"")<<"\n";}
        js<<"  ],\n  \"fiber_min_distance_lower_bound\": "<<(ok&&subsets.size()==21?6:0)<<"\n}\n";
        std::ofstream out(out_path);out<<js.str();std::cout<<js.str();return ok?0:1;
    }catch(const std::exception&e){std::cerr<<"error: "<<e.what()<<"\n";return 3;}
}
