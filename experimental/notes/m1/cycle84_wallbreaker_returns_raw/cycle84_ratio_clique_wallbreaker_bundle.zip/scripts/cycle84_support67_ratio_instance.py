#!/usr/bin/env python3
"""Emit the exact support-6/7 ratio-signature OPB instance for Cycle 84.

The input is the arithmetically verified cycle84_ratio_atoms.csv table.
A model selects one ratio atom in every slot and satisfies:
  support >= 6,
  sum discrete logs == 0 mod (17^16-1),
  sum forced color differences == 0 mod 16.

The instance is an AllSAT/counting target.  Enumerate models with exact
blocking constraints and finish with a proof-producing UNSAT certificate.
"""
from __future__ import annotations
import csv, hashlib, json, pathlib, sys

N = 17**16 - 1

def sha256(path: pathlib.Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20), b''): h.update(b)
    return h.hexdigest()

def main() -> None:
    if len(sys.argv)!=4:
        raise SystemExit('usage: emitter ATOMS.csv INSTANCE.opb CERT.json')
    inp,opb_path,cert_path=map(pathlib.Path,sys.argv[1:])
    slots={t:[] for t in range(1,8)}
    with inp.open(newline='') as f:
        for r in csv.DictReader(f):
            t=int(r['slot'])
            slots[t].append({
                'id':int(r['atom_id']), 'e':int(r['dlog']),
                'd':int(r['delta']), 'non':int(r['nonidentity']),
                'g':int(r['generic'])})
    for t,a in slots.items():
        a.sort(key=lambda r:r['id'])
        assert [r['id'] for r in a]==list(range(1153))
        assert sum(1-r['non'] for r in a)==1
        assert sum(r['non'] and not r['g'] for r in a)==48
        assert sum(r['g'] for r in a)==1104
    with opb_path.open('w') as o:
        o.write('* cycle84 support-6/7 compatible ratio-signature AllSAT instance\n')
        o.write(f'* N={N}; one model = one ordered ratio signature; target model_count < 78\n')
        for t in range(1,8):
            o.write(''.join(f'+1 x{t}_{r["id"]} ' for r in slots[t])+'= 1 ;\n')
        o.write(''.join(f'+1 x{t}_{r["id"]} ' for t in range(1,8) for r in slots[t] if r['non'])+'>= 6 ;\n')
        o.write(''.join(f'+{r["e"]} x{t}_{r["id"]} ' for t in range(1,8) for r in slots[t] if r['e']))
        o.write(f'-{N} k0 -{2*N} k1 -{4*N} k2 = 0 ;\n')
        o.write('+1 k0 +1 k1 +1 k2 <= 2 ;\n')
        o.write(''.join(f'+{r["d"]} x{t}_{r["id"]} ' for t in range(1,8) for r in slots[t] if r['d']))
        o.write('-16 z0 -32 z1 -64 z2 = 0 ;\n')
        o.write('+1 z0 +1 z1 +1 z2 <= 2 ;\n')
    cert={
        'decision':'SUPPORT67_RATIO_SIGNATURE_ALLSAT_INSTANCE_EMITTED_UNSOLVED',
        'field_order_minus_one':str(N),
        'input_ratio_atoms_sha256':sha256(inp),
        'instance_sha256':sha256(opb_path),
        'slots':7,'ratio_atoms_per_slot':1153,
        'identity_atoms_per_slot':1,
        'singleton_nonidentity_atoms_per_slot':48,
        'generic_nonidentity_atoms_per_slot':1104,
        'constraints':['one_hot_per_slot','support_ge_6','sum_dlog_eq_0_mod_N','sum_delta_eq_0_mod_16'],
        'closure_threshold':{'model_count_strictly_less_than':78,'consequence':'m_max_le_12'},
        'blocking_constraint_for_model':'sum_of_its_7_selected_x_variables <= 6',
        'solver_status':'UNRUN'
    }
    cert_path.write_text(json.dumps(cert,indent=2,sort_keys=True)+'\n')
    print(json.dumps(cert,indent=2,sort_keys=True))
if __name__=='__main__': main()
