# Cycle 84 ratio-clique wallbreaker

## Executive verdict

**BANKABLE_LEMMA.** The full bound `m_max <= 12` is not yet proved and no
13-fold packet was found.  The ratio route is nevertheless reduced below the
Cycle 83 MITM wall to one exact AllSAT count:

> Count the compatible support-6/7 ratio signatures.  If there are fewer than
> 78, then `m_max <= 12`.

The new ingredients are an executed five-slot product-injectivity certificate
and an exact local tau-orbit classification of one-slot ratios.

## Model and notation

Let `A={0,...,47}` be the slot alphabet, let `u_t(a)` be the banked nonzero
slot value in `F_{17^16}`, and let `c(a)` be its color in `Z/16Z`.  For a
product/color fiber

```
C_v = {x in A^7 : product_t u_t(x_t)=v and sum_t c(x_t)=4 mod 16},
```

write `m(v)=|C_v|`.

For an ordered pair `(x,y)` in one fiber define its ratio signature

```
q_t = u_t(x_t)/u_t(y_t),  t=1,...,7.
```

For a one-slot ratio atom `q` let `delta_t(q)` be the forced color difference
`c(a)-c(b)` on every ordered realization `u_t(a)/u_t(b)=q`.

A **compatible signature** is a tuple `q=(q_1,...,q_7)` satisfying

```
q_t is a one-slot ratio atom on slot t,
product_t q_t = 1,
sum_t delta_t(q_t) = 0 mod 16,
support(q) >= 6.
```

Let `H` be the number of compatible signatures.

## Lemma 1: exact one-slot tau-orbit rigidity

For each slot, the 2304 ordered endpoint pairs give 1153 distinct ratios:

```
identity:             1 class, 48 diagonal realizations;
nonidentity singleton: 48 classes, 1 realization each;
nonidentity generic: 1104 classes, 2 realizations each.
```

If a nonidentity class contains `(a,b)`, its complete realization set is

```
{(a,b), (tau(b),tau(a))}.
```

The two entries coincide exactly in the singleton case `b=tau(a)`.  The color
difference is forced by the ratio.  Distinct slots have no common
nonidentity ratio atom.

This is checked by `cycle84_ratio_orbit_checker.py`; its decision is

```
ALL_SLOT_RATIO_FIBERS_ARE_TAU_ORBITS_AND_DELTA_IS_FORCED.
```

## Lemma 2: five-slot product injectivity

For every five-element subset `S` of `{1,...,7}`, the map

```
A^S -> F_{17^16}^*,  x |-> product_{t in S} u_t(x_t)
```

is injective.

The executed checker reconstructs exact relative discrete logs

```
log_g(u_t(a)/u_t(0)),  g=X+1,
```

from the independently verified ratio-atom table.  It verifies all 16128
ordered endpoint-ratio identities and, for each of the 21 five-slot subsets,
enumerates all

```
48^5 = 254803968
```

modular log sums.  Equality of products forces equality of these 66-bit sums.
The checker sorts their low 64-bit projections; any projection collision
would trigger an exact 66-bit fallback.  Every subset had zero low-64
collisions, hence zero exact collisions.

Consequently any two distinct words in one product fiber differ in at least
six slots.

## Theorem: 78-signature obstruction

For every shell product fiber `C_v`,

```
|C_v| (|C_v|-1) <= 2 H.
```

Therefore

```
H < 78  =>  m_max <= 12.
```

Equivalently, every coherent compatible ratio clique of size 13 forces at
least 78 compatible support-6/7 signatures.

### Proof

Fix a compatible signature `q`, let

```
s = support(q) in {6,7},
h = 7-s,
g = number of generic active coordinates.
```

Consider all directed edges `(x,y)` in one fixed fiber `C_v` having signature
`q`.  The source `x` determines `y`, since each one-slot value map is
injective.

At a singleton active coordinate the source symbol is fixed.  At a generic
active coordinate there are exactly two possible source symbols, encoded by
one orientation bit.  At an inactive coordinate `x_t=y_t` and the common
symbol is unrestricted.

Take two distinct source words of edges with signature `q`.  They lie in the
same product fiber, so Lemma 2 gives Hamming distance at least 6.  Inactive
coordinates contribute at most `h` differences, singleton active coordinates
contribute none, and generic coordinates contribute exactly the Hamming
distance between the orientation vectors.  Hence the orientation vectors form
a binary code of length `g` and minimum distance at least

```
6-h = s-1.
```

For `s=6` this is `A_2(g,5)`, and for `s=7` it is `A_2(g,6)`.  The exact tiny
capacities are

```
A_2(g,5) <= 2 for g<=6,
A_2(g,6) <= 2 for g<=7.
```

Thus one signature supports at most two directed edges in a fixed fiber.
Every ordered pair of distinct words in `C_v` has a compatible signature, so
summing over all `H` signatures yields

```
|C_v|(|C_v|-1) <= 2H.
```

If `|C_v|>=13`, the left side is at least `13*12=156`; hence `H>=78`.

## Inversion check

Signature inversion `q -> q^{-1}` preserves compatibility and support.  It
has no fixed compatible signature: a fixed point would require every active
coordinate to have ratio `-1`, but distinct slots have disjoint nonidentity
ratio alphabets and support is at least 6.  Therefore `H` is even.  The exact
closure target may equivalently be stated as `H<=76`.

## Exact remaining checker

The emitted OPB instance

```
cycle84_support67_ratio_signature_instance.opb
```

has one model per compatible support-6/7 signature.  The exact next target is

```
V-CYCLE84-78TH-SUPPORT67-RATIO-SIGNATURE
```

Run proof-producing AllSAT:

1. find a model;
2. record its seven atom IDs;
3. append the exact blocking constraint
   `sum(the seven selected x variables) <= 6`;
4. repeat;
5. finish with a checked UNSAT proof.

If final UNSAT occurs after at most 77 models, the theorem proves
`m_max<=12`.  Because inversion makes the count even, a complete list should
in fact contain at most 76 models.  If a 78th model exists, this counting
lemma alone does not produce a 13-packet; the 78 signatures must then be fed
into the endpoint-coherence graph.

The AllSAT step is **UNRUN**.  This is the exact remaining finite wall.
