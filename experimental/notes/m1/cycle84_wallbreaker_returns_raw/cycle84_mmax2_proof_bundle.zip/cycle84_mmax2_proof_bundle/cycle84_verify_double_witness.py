#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('V',ROOT/'cycle84_verify_discrete_logs_stdlib.py');V=importlib.util.module_from_spec(spec);assert spec.loader;spec.loader.exec_module(V)
w=json.loads((ROOT/'cycle84_double_witness.json').read_text()); target=int(w['product_log'])
products=[]; sums=[]; colors=[]
for rep in w['representations']:
 p=V.ONE;s=0;c=0
 for q in rep['slots']:
  t,i,a=q['t'],q['i'],q['a'];u=V.build_u(t,i,a);p=V.fmul(p,u)
  k=(t-1)*48+(i-1)*16+a;s=(s+V.LOGS[k])%V.N;c=(c+(V.S_COLOR[i]+8*(a&1)))%16
 assert c==4 and s==target and p==V.fpow(V.GENERATOR,target)
 products.append(p);sums.append(s);colors.append(c)
assert len(products)==2 and products[0]==products[1]
cert={'decision':'DOUBLE_WITNESS_EXACTLY_VERIFIED_AS_COLLISION','product_log':target,'product_field_coefficients':list(products[0]),'representations_checked':2,'colors':colors,'log_sums':sums,'witness_sha256':hashlib.sha256((ROOT/'cycle84_double_witness.json').read_bytes()).hexdigest()}
print(json.dumps(cert,indent=2,sort_keys=True))
