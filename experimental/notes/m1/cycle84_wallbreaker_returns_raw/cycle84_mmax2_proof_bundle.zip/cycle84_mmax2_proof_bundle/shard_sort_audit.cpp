#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <vector>
#include <string>
#include "slot_logs_generated.h"
using u128=unsigned __int128;
static inline u128 mk(uint64_t h,uint64_t l){return ((u128)h<<64)|l;}static const u128 MOD=mk(N_HI,N_LO);
static inline u128 w(int t,int k){return mk(W_HI[t][k],W_LO[t][k]);}static inline u128 addm(u128 a,u128 b){u128 s=a+b;return s>=MOD?s-MOD:s;}
struct ARec{u128 x;uint8_t c;};struct BRec{u128 x;};
static inline size_t lb(const std::vector<BRec>&v,u128 x){return std::lower_bound(v.begin(),v.end(),x,[](auto&a,u128 y){return a.x<y;})-v.begin();}
int main(int argc,char**argv){uint32_t sh=argc>1?std::stoul(argv[1]):0,NS=argc>2?std::stoul(argv[2]):1536;std::vector<ARec>A;std::array<std::vector<BRec>,16>B;
for(int a=0;a<48;a++)for(int b=0;b<48;b++){u128 s=addm(w(1,a),w(2,b));int c=(COL[a]+COL[b])&15;for(int d=0;d<48;d++)A.push_back({addm(s,w(3,d)),(uint8_t)((c+COL[d])&15)});}
for(int a=0;a<48;a++)for(int b=0;b<48;b++){u128 s=addm(w(4,a),w(5,b));int c=(COL[a]+COL[b])&15;for(int d=0;d<48;d++){u128 q=addm(s,w(6,d));int cc=(c+COL[d])&15;for(int e=0;e<48;e++)B[(cc+COL[e])&15].push_back({addm(q,w(7,e))});}}
for(auto&v:B)std::sort(v.begin(),v.end(),[](auto&a,auto&b){return a.x<b.x;});u128 L=MOD*sh/NS,U=MOD*(sh+1)/NS;std::vector<uint64_t>K;K.reserve(35000000);
for(auto&a:A){auto&v=B[(4-a.c)&15];u128 lo=L>=a.x?L-a.x:L+MOD-a.x,hi=U>=a.x?U-a.x:U+MOD-a.x;auto run=[&](size_t p,size_t q){for(size_t j=p;j<q;j++){u128 s=addm(a.x,v[j].x);K.push_back((uint64_t)(s-L));}};if(lo<hi)run(lb(v,lo),lb(v,hi));else{run(lb(v,lo),v.size());run(0,lb(v,hi));}}
std::sort(K.begin(),K.end());uint64_t uniq=0,D=0;unsigned mx=0;for(size_t i=0;i<K.size();){size_t j=i+1;while(j<K.size()&&K[j]==K[i])j++;uint64_t m=j-i;uniq++;D+=m*(m-1);if(m>mx)mx=m;i=j;}printf("shard=%u NS=%u pairs=%zu unique=%llu D=%llu max=%u\n",sh,NS,K.size(),(unsigned long long)uniq,(unsigned long long)D,mx);
}
