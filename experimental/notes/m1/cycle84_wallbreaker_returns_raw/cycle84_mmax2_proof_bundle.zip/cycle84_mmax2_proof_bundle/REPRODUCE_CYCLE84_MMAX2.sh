#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE"
python3 cycle84_verify_discrete_logs_stdlib.py | tee reproduced_slot_log_certificate.json
g++ -O3 -std=c++17 -pthread cycle84_exact_mmax_checker.cpp -o reproduced_cycle84_checker
./reproduced_cycle84_checker 0 1536 1536 4 reproduced_full_certificate.json
python3 cycle84_check_full_certificate.py reproduced_full_certificate.json | tee reproduced_acceptance_certificate.json
python3 cycle84_verify_double_witness.py | tee reproduced_double_witness_certificate.json
