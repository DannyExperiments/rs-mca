#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <vector>
#include <array>
#include "slot_logs_generated.h"
using u128=unsigned __int128;
static inline u128 mk(uint64_t hi,uint64_t lo){return ((u128)hi<<64)|lo;}
static const u128 MOD=mk(N_HI,N_LO);
static inline u128 w(int t,int k){return mk(W_HI[t][k],W_LO[t][k]);}
static inline u128 addm(u128 a,u128 b){u128 s=a+b; if(s>=MOD)s-=MOD; return s;}
static inline u128 subm(u128 a,u128 b){return a>=b?a-b:a+MOD-b;}
struct Rec { u128 x; uint32_t idx; uint8_t c; };
static bool operator<(Rec const&a,Rec const&b){return a.x<b.x || (a.x==b.x && a.c<b.c);}
static void print128(u128 x){char b[64]; int n=0; if(!x){putchar('0');return;} while(x){b[n++]='0'+x%10;x/=10;}while(n)putchar(b[--n]);}
int main(){
  std::vector<Rec> R; R.resize(48ull*48*48*48);
  size_t z=0;
  for(int k4=0;k4<48;k4++)for(int k5=0;k5<48;k5++){
    u128 s45=addm(w(4,k4),w(5,k5)); int c45=(COL[k4]+COL[k5])&15;
    for(int k6=0;k6<48;k6++){
      u128 s456=addm(s45,w(6,k6)); int c456=(c45+COL[k6])&15;
      for(int k7=0;k7<48;k7++){
        R[z++]={addm(s456,w(7,k7)),(uint32_t)(((k4*48+k5)*48+k6)*48+k7),(uint8_t)((c456+COL[k7])&15)};
      }
    }
  }
  std::sort(R.begin(),R.end());
  for(size_t i=1;i<R.size();i++) if(R[i].x==R[i-1].x){fprintf(stderr,"RIGHT_DUP\n");return 2;}
  // K from tau(1,0)=(2,6)
  u128 K=0; for(int t=1;t<=7;t++) K=addm(K,addm(w(t,0),w(t,16+6)));
  if((K&1)!=0){puts("K_NONSQUARE");return 0;}
  u128 roots[2]={K/2,K/2+MOD/2};
  for(int rr=0;rr<2;rr++){
    uint64_t count=0; std::array<uint32_t,16> wit{}; int nw=0;
    for(int k1=0;k1<48;k1++)for(int k2=0;k2<48;k2++){
      u128 s12=addm(w(1,k1),w(2,k2)); int c12=(COL[k1]+COL[k2])&15;
      for(int k3=0;k3<48;k3++){
        u128 a=addm(s12,w(3,k3)); int ca=(c12+COL[k3])&15;
        u128 need=subm(roots[rr],a); uint8_t cr=(4-ca)&15;
        Rec key{need,0,cr};
        auto it=std::lower_bound(R.begin(),R.end(),key);
        if(it!=R.end() && it->x==need && it->c==cr){ count++; if(nw<16)wit[nw++]=(uint32_t)(((k1*48+k2)*48+k3)); }
      }
    }
    printf("root%d=",rr);print128(roots[rr]);printf(" count=%llu\n",(unsigned long long)count);
  }
  return 0;
}
