#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "slot_logs_generated.h"
using u128=unsigned __int128;
static inline u128 mk(uint64_t hi,uint64_t lo){return ((u128)hi<<64)|lo;}
static const u128 MOD=mk(N_HI,N_LO);
static inline u128 w(int t,int k){return mk(W_HI[t][k],W_LO[t][k]);}
static inline u128 addm(u128 a,u128 b){u128 s=a+b; if(s>=MOD)s-=MOD; return s;}
static std::string dec128(u128 x){if(!x)return "0";char b[64];int n=0;while(x){b[n++]='0'+x%10;x/=10;}std::string s;while(n)s+=b[--n];return s;}
struct LRec{u128 x; uint32_t idx; uint8_t c;};
struct BRec{u128 x; uint32_t idx;};
static std::vector<LRec> A;
static std::array<std::vector<BRec>,16> B;
static constexpr uint64_t KEYMASK=(1ULL<<56)-1;
static inline uint64_t mix64(uint64_t x){x^=x>>30;x*=0xbf58476d1ce4e5b9ULL;x^=x>>27;x*=0x94d049bb133111ebULL;x^=x>>31;return x;}
struct Result{uint64_t pairs=0,unique=0,D=0;uint8_t maxc=0;bool hit=false;u128 hitv=0;double sec=0;};
static inline size_t lb(const std::vector<BRec>&v,u128 x){return std::lower_bound(v.begin(),v.end(),x,[](const BRec&a,u128 y){return a.x<y;})-v.begin();}
static inline uint64_t range_count(const std::vector<BRec>&v,u128 lo,u128 hi){
 if(lo<hi)return lb(v,hi)-lb(v,lo);
 if(lo>hi)return (v.size()-lb(v,lo))+lb(v,hi);
 std::abort();
}
static Result process_shard(uint32_t sh,uint32_t NS){
 auto st=std::chrono::steady_clock::now();u128 L=(MOD*sh)/NS,U=(MOD*(sh+1))/NS;
 uint64_t np=0;
 for(const auto&a:A){const auto&v=B[(4-a.c)&15];u128 lo=L>=a.x?L-a.x:L+MOD-a.x,hi=U>=a.x?U-a.x:U+MOD-a.x;np+=range_count(v,lo,hi);}
 size_t cap=1;while(cap<(size_t)(np/0.55)+1)cap<<=1;
 std::vector<uint64_t> table(cap,0);size_t mask=cap-1;Result out;out.pairs=np;
 auto insert=[&](u128 sum){
  uint64_t off=(uint64_t)(sum-L),kp=off+1;size_t h=mix64(off)&mask;
  while(true){uint64_t e=table[h];if(!e){table[h]=(1ULL<<56)|kp;out.unique++;if(out.maxc<1)out.maxc=1;return false;}
   if((e&KEYMASK)==kp){unsigned old=e>>56,now=old+1;out.D+=2ull*old;table[h]=((uint64_t)now<<56)|kp;if(now>out.maxc)out.maxc=now;if(now>=13){out.hit=true;out.hitv=sum;return true;}return false;}h=(h+1)&mask;}
 };
 for(const auto&a:A){const auto&v=B[(4-a.c)&15];u128 lo=L>=a.x?L-a.x:L+MOD-a.x,hi=U>=a.x?U-a.x:U+MOD-a.x;
  auto run=[&](size_t p,size_t q){for(size_t j=p;j<q;j++)if(insert(addm(a.x,v[j].x)))return true;return false;};
  if(lo<hi){if(run(lb(v,lo),lb(v,hi)))break;}else{if(run(lb(v,lo),v.size()))break;if(run(0,lb(v,hi)))break;}if(out.hit)break;
 }
 out.sec=std::chrono::duration<double>(std::chrono::steady_clock::now()-st).count();return out;
}
int main(int argc,char**argv){
 uint32_t NS=8192,start=0,count=8192,nt=18;std::string outpath="/mnt/data/cycle84_ctx/cycle84_mmax_certificate.json";
 if(argc>1)start=std::stoul(argv[1]);if(argc>2)count=std::stoul(argv[2]);if(argc>3)NS=std::stoul(argv[3]);if(argc>4)nt=std::stoul(argv[4]);if(argc>5)outpath=argv[5];
 if(start+count>NS){fprintf(stderr,"bad range\n");return 2;}
 auto allst=std::chrono::steady_clock::now();A.reserve(48*48*48);
 for(int k1=0;k1<48;k1++)for(int k2=0;k2<48;k2++){u128 s12=addm(w(1,k1),w(2,k2));int c12=(COL[k1]+COL[k2])&15;for(int k3=0;k3<48;k3++)A.push_back({addm(s12,w(3,k3)),(uint32_t)((k1*48+k2)*48+k3),(uint8_t)((c12+COL[k3])&15)});}
 for(int k4=0;k4<48;k4++)for(int k5=0;k5<48;k5++){u128 s45=addm(w(4,k4),w(5,k5));int c45=(COL[k4]+COL[k5])&15;for(int k6=0;k6<48;k6++){u128 s456=addm(s45,w(6,k6));int c456=(c45+COL[k6])&15;for(int k7=0;k7<48;k7++)B[(c456+COL[k7])&15].push_back({addm(s456,w(7,k7)),(uint32_t)(((k4*48+k5)*48+k6)*48+k7)});}}
 for(auto&v:B)std::sort(v.begin(),v.end(),[](auto&a,auto&b){return a.x<b.x;});
 std::vector<Result> R(count);std::atomic<uint32_t> next{0};std::atomic<bool> stop{false};
 std::mutex pm;
 auto worker=[&](uint32_t tid){while(true){uint32_t i=next.fetch_add(1);if(i>=count||stop.load())break;uint32_t sh=start+i;R[i]=process_shard(sh,NS);if(R[i].hit)stop=true;if((i%128)==0){std::lock_guard<std::mutex>g(pm);fprintf(stderr,"progress assigned=%u/%u last_shard=%u sec=%.3f max=%u D=%llu\n",std::min(next.load(),count),count,sh,R[i].sec,R[i].maxc,(unsigned long long)R[i].D);}}};
 std::vector<std::thread> th;for(uint32_t i=0;i<nt;i++)th.emplace_back(worker,i);for(auto&t:th)t.join();
 uint64_t pairs=0,unique=0,Dtot=0;unsigned mmax=0;bool hit=false;u128 hitv=0;uint64_t chk1=0,chk2=0;
 uint32_t done=0;for(uint32_t i=0;i<count;i++){if(R[i].pairs==0&&R[i].unique==0&&R[i].sec==0)continue;done++;pairs+=R[i].pairs;unique+=R[i].unique;Dtot+=R[i].D;mmax=std::max<unsigned>(mmax,R[i].maxc);if(R[i].hit){hit=true;hitv=R[i].hitv;}uint64_t x=R[i].pairs^(R[i].unique*0x9e3779b97f4a7c15ULL)^(R[i].D<<1)^R[i].maxc;chk1^=mix64(x+i);chk2+=mix64(x+0x517cc1b727220a95ULL*(i+1));}
 double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-allst).count();
 std::ofstream o(outpath);o<<"{\n  \"decision\": \""<<(hit?"THIRTEEN_FOLD_PACKET_REQUIRED":(start==0&&count==NS?"MMAX_CERTIFIED_LE_12":"PARTIAL_SHARD_PASS"))<<"\",\n";
 o<<"  \"model\": {\"field_poly\": [3,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1], \"eta\": [0,0,0,0,0,0,0,0,0,6], \"beta\": [2,1], \"generator\": [1,1], \"group_order\": \""<<dec128(MOD)<<"\"},\n";
 o<<"  \"split\": {\"left_slots\": [1,2,3], \"right_slots\": [4,5,6,7], \"left_count\": "<<A.size()<<", \"right_count\": "<<(48ull*48*48*48)<<"},\n";
 o<<"  \"color_filter\": \"colorL + colorR == 4 mod 16\",\n";
 o<<"  \"shards\": {\"total\": "<<NS<<", \"start\": "<<start<<", \"requested\": "<<count<<", \"completed\": "<<done<<", \"threads\": "<<nt<<"},\n";
 o<<"  \"compatible_pairs\": "<<pairs<<",\n  \"distinct_products\": "<<unique<<",\n  \"D_offdiagonal_ordered\": "<<Dtot<<",\n  \"m_max\": "<<mmax<<",\n";
 o<<"  \"threshold\": 12,\n  \"hit_value_log\": "<<(hit?("\""+dec128(hitv)+"\""):"null")<<",\n";
 o<<"  \"aggregate_checksums\": {\"xor64\": \""<<chk1<<"\", \"sum64\": \""<<chk2<<"\"},\n  \"elapsed_seconds\": "<<elapsed<<"\n}\n";o.close();
 printf("done=%u pairs=%llu unique=%llu D=%llu mmax=%u hit=%d elapsed=%.3f cert=%s\n",done,(unsigned long long)pairs,(unsigned long long)unique,(unsigned long long)Dtot,mmax,hit,elapsed,outpath.c_str());
 return hit?13:0;
}
