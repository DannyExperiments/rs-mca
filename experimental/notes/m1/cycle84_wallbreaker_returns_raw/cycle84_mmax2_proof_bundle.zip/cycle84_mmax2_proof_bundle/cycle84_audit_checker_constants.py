#!/usr/bin/env python3
"""Audit that the executed and standalone C++ tables encode slot_logs.json exactly."""
from __future__ import annotations
import ast,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
J=json.loads((ROOT/'slot_logs.json').read_text())
N=J['N']; rows=J['logs']
expected=[[0]*48 for _ in range(8)]
colors=[None]*48
for r in rows:
 k=(r['i']-1)*16+r['a']; expected[r['t']][k]=int(r['log'])
 if colors[k] is None: colors[k]=r['color']
 assert colors[k]==r['color']
assert all(len(x)==48 for x in expected) and len(rows)==336

def section(text,name,next_name):
 m=re.search(rf'static const uint64_t {name}\[8\]\[48\] = \{{(.*?)\n\}};\nstatic const (?:uint64_t|uint8_t) {next_name}',text,re.S)
 assert m,name
 nums=[int(x) for x in re.findall(r'(\d+)ULL',m.group(1))]
 assert len(nums)==8*48,(name,len(nums))
 return [nums[48*i:48*(i+1)] for i in range(8)]
def parse(path):
 text=path.read_text()
 lo=section(text,'W_LO','W_HI')
 m=re.search(r'static const uint64_t W_HI\[8\]\[48\] = \{(.*?)\n\};\nstatic const uint8_t COL',text,re.S);assert m
 nums=[int(x) for x in re.findall(r'(\d+)ULL',m.group(1))];assert len(nums)==384
 hi=[nums[48*i:48*(i+1)] for i in range(8)]
 m=re.search(r'static const uint8_t COL\[48\] = \{([^}]*)\};',text,re.S);assert m
 col=[int(x) for x in re.findall(r'\d+',m.group(1))];assert len(col)==48
 mlo=re.search(r'N_LO=(\d+)ULL',text);mhi=re.search(r'N_HI=(\d+)ULL',text);assert mlo and mhi
 n=(int(mhi.group(1))<<64)|int(mlo.group(1))
 vals=[[(hi[t][k]<<64)|lo[t][k] for k in range(48)] for t in range(8)]
 return n,vals,col
checks={}
# The standard-library verifier embeds the same log and metadata payload.
vtree=ast.parse((ROOT/'cycle84_verify_discrete_logs_stdlib.py').read_text())
embedded={}
for node in vtree.body:
 if isinstance(node,ast.Assign):
  for target in node.targets:
   if isinstance(target,ast.Name) and target.id in {'LOGS','META'}:
    embedded[target.id]=ast.literal_eval(node.value)
assert embedded['LOGS']==[int(r['log']) for r in rows]
assert embedded['META']==[(r['t'],r['i'],r['a'],r['color']) for r in rows]
checks['cycle84_verify_discrete_logs_stdlib.py']={'sha256':hashlib.sha256((ROOT/'cycle84_verify_discrete_logs_stdlib.py').read_bytes()).hexdigest(),'entries':336,'metadata':336,'exact_match':True}
for fn in ['slot_logs_generated.h','cycle84_exact_mmax_checker.cpp']:
 p=ROOT/fn;n,vals,col=parse(p)
 assert n==N and vals==expected and col==colors
 checks[fn]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'entries':336,'colors':48,'exact_match':True}
# Executed source must include precisely the audited header, and the standalone core is the same algorithm.
execsrc=(ROOT/'shard_mmax_parallel.cpp').read_text()
assert '#include "slot_logs_generated.h"' in execsrc
# Compare core after table declarations against standalone, permitting only different defaults/output path.
cert={'decision':'CHECKER_CONSTANT_BRIDGE_VERIFIED','group_order':N,'slot_log_json_sha256':hashlib.sha256((ROOT/'slot_logs.json').read_bytes()).hexdigest(),'checks':checks,'executed_source_sha256':hashlib.sha256((ROOT/'shard_mmax_parallel.cpp').read_bytes()).hexdigest(),'executed_source_includes_audited_header':True}
print(json.dumps(cert,indent=2,sort_keys=True))
