Cycle 84 ratio-clique wallbreaker reproduction

1. Local ratio orbit certificate:
   python scripts/cycle84_ratio_orbit_checker.py > certificates/cycle84_ratio_orbit_certificate.json

2. Exact ratio atoms and original PB instance:
   g++ -O3 -std=c++20 scripts/cycle84_ratio_signature_instance.cpp -o /tmp/c84_atoms
   /tmp/c84_atoms certificates/cycle84_ratio_atoms.csv certificates/cycle84_ratio_signature_instance.opb certificates/cycle84_ratio_signature_instance_certificate.json

3. Five-slot injectivity (about 2.1 GB peak memory; OpenMP):
   g++ -O3 -march=native -fopenmp -std=c++20 scripts/cycle84_five_slot_dlog_injectivity.cpp -o /tmp/c84_check5
   /tmp/c84_check5 certificates/cycle84_ratio_atoms.csv --all certificates/cycle84_five_slot_dlog_injectivity_certificate.json

4. Tiny binary capacities:
   python scripts/cycle84_dmin6_signature_capacity_checker.py > certificates/cycle84_dmin6_signature_capacity_certificate.json

5. Emit the final support-6/7 AllSAT instance:
   python scripts/cycle84_support67_ratio_instance.py certificates/cycle84_ratio_atoms.csv certificates/cycle84_support67_ratio_signature_instance.opb certificates/cycle84_support67_ratio_signature_instance_certificate.json

6. UNRUN exact closure:
   Enumerate every model of the support-6/7 OPB with proof-producing blocking.
   Fewer than 78 models proves m_max <= 12.
