#!/usr/bin/env python3
"""Cycle 84 exact one-slot ratio-orbit certificate.

This checker establishes the local rigidity used by the ratio-signature
clique bound.  It is a bounded exact check: 7 slots x 48^2 ordered pairs.
Equality is packed field equality; color is only an annotation.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
C68_PATH = SCRIPT_DIR / "cycle68_slot_factorization_checker.py"
P = 17
NDEG = 16


def load_cycle68():
    spec = importlib.util.spec_from_file_location("cycle68_checker", C68_PATH)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def dense(v):
    out = [0] * NDEG
    for i, c in enumerate(v[:NDEG]):
        out[i] = c % P
    return tuple(out)


def pack(v):
    z = 0
    for c in reversed(v):
        z = z * P + c
    return z


def main():
    c68 = load_cycle68()
    f = c68.find_field_poly()
    eta = c68.find_eta(f)
    beta = c68.find_beta(f)
    raw = c68.build_u(f, eta, beta)
    one = dense(c68.ONE)

    def color(k: int) -> int:
        i, a = k // 16 + 1, k % 16
        return (c68.S_COLOR[i] + 8 * (a & 1)) % 16

    def tau(k: int) -> int:
        i, a = k // 16 + 1, k % 16
        if i == 1:
            return 16 + ((a + 6) % 16)
        if i == 2:
            return ((a + 10) % 16)
        return 32 + ((a + 8) % 16)

    # Involutivity and fixed-point freeness are exact label checks.
    for k in range(48):
        assert tau(tau(k)) == k
        assert tau(k) != k
        assert (color(tau(k)) - (8 - color(k))) % 16 == 0

    canonical_rows = []
    slot_results = []
    ratio_sets = []

    for t in range(1, 8):
        vals = [dense(raw[(t, k // 16 + 1, k % 16)]) for k in range(48)]
        inv = [dense(c68.fpow(vals[k], c68.N - 1, f)) for k in range(48)]
        classes = defaultdict(list)
        for a in range(48):
            for b in range(48):
                q = dense(c68.fmul(vals[a], inv[b], f))
                classes[q].append((a, b))

        assert len(classes) == 1153
        assert len(classes[one]) == 48
        assert set(classes[one]) == {(k, k) for k in range(48)}

        nontrivial = {q: pairs for q, pairs in classes.items() if q != one}
        multiplicities = Counter(len(pairs) for pairs in nontrivial.values())
        assert multiplicities == Counter({2: 1104, 1: 48})

        singleton_count = 0
        doubleton_count = 0
        for q, pairs in nontrivial.items():
            pairset = set(pairs)
            # Every ratio fiber is exactly the orbit under
            # sigma(a,b)=(tau(b),tau(a)).
            closure = {(tau(b), tau(a)) for a, b in pairs}
            assert pairset == closure
            assert len(pairset) in (1, 2)
            if len(pairset) == 1:
                singleton_count += 1
                (a, b), = pairset
                assert b == tau(a)
            else:
                doubleton_count += 1

            deltas = {(color(a) - color(b)) % 16 for a, b in pairs}
            assert len(deltas) == 1
            delta = next(iter(deltas))
            qkey = pack(q)
            canonical_rows.append((t, qkey, delta, tuple(sorted(pairset))))

        assert singleton_count == 48
        assert doubleton_count == 1104
        ratio_sets.append(set(classes.keys()))
        slot_results.append({
            "slot": t,
            "ordered_pairs": 48**2,
            "distinct_ratios": 1153,
            "identity_fiber_size": 48,
            "nontrivial_ratio_classes": 1152,
            "nontrivial_singleton_orbits": 48,
            "nontrivial_doubleton_orbits": 1104,
            "max_nontrivial_ratio_fiber": 2,
            "color_difference_forced_by_ratio": True,
        })

    # Cross-slot nonidentity ratio sets are disjoint. This is also a
    # consequence of banked two-slot product injectivity, but is checked here.
    cross = []
    for i in range(7):
        for j in range(i + 1, 7):
            inter = ratio_sets[i] & ratio_sets[j]
            assert inter == {one}
            cross.append({"slots": [i + 1, j + 1], "intersection_size": 1})

    canonical_rows.sort()
    digest = hashlib.sha256(repr(canonical_rows).encode("utf-8")).hexdigest()
    out = {
        "model": {
            "field_poly": list(f),
            "eta": list(eta),
            "beta": list(beta),
        },
        "key": "packed_field_ratio_only",
        "tau": {
            "1,a": "2,a+6",
            "2,a": "1,a+10",
            "3,a": "3,a+8",
            "modulus": 16,
            "involutive_fixed_point_free": True,
        },
        "slots_checked": 7,
        "slot_results": slot_results,
        "cross_slot_checks": cross,
        "canonical_ratio_table_sha256": digest,
        "decision": "ALL_SLOT_RATIO_FIBERS_ARE_TAU_ORBITS_AND_DELTA_IS_FORCED",
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
