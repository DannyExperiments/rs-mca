#!/usr/bin/env python3
"""Validate a full certificate emitted by cycle84_exact_mmax_checker.cpp."""
from __future__ import annotations
import argparse,json
P0=52_747_567_104
EXPECTED_U=52_747_567_092
EXPECTED_D=24

def main():
 ap=argparse.ArgumentParser();ap.add_argument('certificate');a=ap.parse_args()
 d=json.load(open(a.certificate))
 assert d['decision']=='MMAX_CERTIFIED_LE_12'
 assert d['model']['group_order']=='48661191875666868480'
 assert d['split']=={'left_slots':[1,2,3],'right_slots':[4,5,6,7],'left_count':110592,'right_count':5308416}
 assert d['color_filter']=='colorL + colorR == 4 mod 16'
 s=d['shards'];assert s['total']==s['start']+s['requested']==s['completed']==1536 and s['start']==0
 assert d['compatible_pairs']==P0
 assert d['distinct_products']==EXPECTED_U
 assert d['D_offdiagonal_ordered']==EXPECTED_D
 assert d['hit_value_log'] is None
 # Histogram rigidity: D - 2(P-U) = sum_v (m_v-1)(m_v-2) = 0.
 excess=P0-EXPECTED_U
 defect=EXPECTED_D-2*excess
 assert excess==12 and defect==0
 assert d['m_max']==2
 out={'decision':'CYCLE84_FULL_CERTIFICATE_ACCEPTED','m_max':2,'singleton_fibers':EXPECTED_U-excess,'double_fibers':excess,'fibers_ge_3':0,'identity_defect':defect}
 print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
