#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,platform,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256((R/p).read_bytes()).hexdigest()
f=json.loads((R/'fresh_full_certificate.json').read_text())
a=json.loads((R/'fresh_full_acceptance_certificate.json').read_text())
base=json.loads((R/'cycle84_mmax_exact_certificate.json').read_text())
assert a['decision']=='CYCLE84_FULL_CERTIFICATE_ACCEPTED'
for k in ['compatible_pairs','distinct_products','D_offdiagonal_ordered','m_max']:
 assert f[k]==base[k]
out={'decision':'FRESH_SOURCE_REBUILD_FULL_RERUN_MATCH','compile_command':'g++ -O3 -std=c++17 -pthread cycle84_exact_mmax_checker.cpp -o cycle84_exact_mmax_checker_fresh','run_command':'./cycle84_exact_mmax_checker_fresh 0 1536 1536 4 fresh_full_certificate.json','compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],'platform':platform.platform(),'matching_fields':{k:f[k] for k in ['compatible_pairs','distinct_products','D_offdiagonal_ordered','m_max']},'sha256':{'source':sha('cycle84_exact_mmax_checker.cpp'),'binary':sha('cycle84_exact_mmax_checker_fresh'),'certificate':sha('fresh_full_certificate.json'),'acceptance':sha('fresh_full_acceptance_certificate.json')}}
(R/'fresh_execution_manifest.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
