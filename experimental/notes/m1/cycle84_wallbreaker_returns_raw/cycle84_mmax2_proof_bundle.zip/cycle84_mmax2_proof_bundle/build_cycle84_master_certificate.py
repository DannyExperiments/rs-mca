#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parent
def sha(name):return hashlib.sha256((R/name).read_bytes()).hexdigest()
base=json.loads((R/'cycle84_mmax_exact_certificate.json').read_text())
assert base['decision']=='MMAX_EXACT_CERTIFIED' and base['m_max']==2
P=base['compatible_pairs'];U=base['distinct_products'];D=base['D_offdiagonal_ordered']
assert P==52_747_567_104 and U==52_747_567_092 and D==24
assert D-2*(P-U)==0
wit=json.loads((R/'cycle84_double_witness_verification_certificate.json').read_text())
assert wit['decision']=='DOUBLE_WITNESS_EXACTLY_VERIFIED_AS_COLLISION'
files=['cycle84_mmax_exact_certificate.json','cycle84_exact_mmax_checker.cpp','cycle84_verify_discrete_logs_stdlib.py','slot_logs_stdlib_verification_certificate.json','checker_constant_bridge_certificate.json','color_count_certificate.json','selfdual_fiber_certificate.json','shard_sort_audit_certificate.json','shard25_sort_audit_certificate.json','cycle84_collision_shard_three_way_certificate.json','cycle84_double_witness.json','cycle84_double_witness_verification_certificate.json','CYCLE84_MMAX2_PROOF.md','REPRODUCE_CYCLE84_MMAX2.sh']
fresh=R/'fresh_full_certificate.json'
if fresh.exists():files+=['fresh_full_certificate.json','fresh_full_acceptance_certificate.json','fresh_execution_manifest.json','fresh_build.sha256']
out={
 'decision':'CYCLE84_FINITE_WALL_PROVED',
 'theorem':'For the explicit Cycle84 seven-slot product/color model at beta=X+2, m_max(beta)=2.',
 'confidence':'high',
 'scope':'finite Cycle84 model only; not a prize-level resolution',
 'model':base['model'],'split':base['split'],'color_filter':base['color_filter'],
 'fiber_histogram':{'multiplicity_1':U-(P-U),'multiplicity_2':P-U,'multiplicity_ge_3':0},
 'compatible_pairs':P,'distinct_products':U,'D_offdiagonal_ordered':D,'m_max':2,
 'histogram_rigidity_identity':{'formula':'D - 2(P-U) = sum_{occupied v}(m(v)-1)(m(v)-2)','value':0},
 'occupancy_threshold':2**32,'occupancy_margin':U-2**32,
 'explicit_double_witness':{'product_log':wit['product_log'],'product_field_coefficients':wit['product_field_coefficients'],'representations':2},
 'verification_layers':[
  '336 exact slot logarithms reconstructed and verified in the finite field',
  'all 1536 log shards exactly enumerated',
  'compatible-pair total equals the independent color count',
  'independent sort reducer matches audit shard 0 and collision shard 25',
  'collision shard 25 also matches an O0 single-thread hash run',
  'tau self-dual fibers are empty and D is divisible by 4',
  'explicit double fiber verified by direct field multiplication'
 ],
 'sha256':{name:sha(name) for name in files}
}
(R/'cycle84_master_proof_certificate.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:out[k] for k in ['decision','theorem','fiber_histogram','compatible_pairs','distinct_products','D_offdiagonal_ordered','m_max','occupancy_margin']},indent=2))
