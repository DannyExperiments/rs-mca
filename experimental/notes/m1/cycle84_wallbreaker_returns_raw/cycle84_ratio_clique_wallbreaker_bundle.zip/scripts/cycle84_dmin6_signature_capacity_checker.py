#!/usr/bin/env python3
"""Exact binary capacities for the d_min>=6 Cycle 84 signature bound."""
from __future__ import annotations
import json

def max_clique_binary(n: int, d: int):
    nv=1<<n
    adj=[0]*nv
    for x in range(nv):
        m=0
        for y in range(nv):
            if x!=y and (x^y).bit_count()>=d:m|=1<<y
        adj[x]=m
    best=[]
    def go(chosen,cand):
        nonlocal best
        if len(chosen)+cand.bit_count()<=len(best):return
        if not cand:
            if len(chosen)>len(best):best=chosen.copy()
            return
        while cand:
            if len(chosen)+cand.bit_count()<=len(best):return
            bit=cand&-cand;v=bit.bit_length()-1;cand^=bit
            go(chosen+[v],cand&adj[v])
    go([], (1<<nv)-1)
    return len(best),[format(x,f'0{n}b') for x in best]

def main():
    req=[(5,5),(6,5),(6,6),(7,6)]
    vals=[]
    for n,d in req:
        a,w=max_clique_binary(n,d);vals.append({'n':n,'d':d,'A2':a,'witness':w})
    assert {(x['n'],x['d']):x['A2'] for x in vals}=={(5,5):2,(6,5):2,(6,6):2,(7,6):2}
    out={'decision':'DMIN6_RATIO_SIGNATURE_CAPACITY_AT_MOST_2','results':vals,
         'capacity_table':{'support_6':{'generic_0_4':1,'generic_5_6':2},
                           'support_7':{'generic_0_5':1,'generic_6_7':2}}}
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
