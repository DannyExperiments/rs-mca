BANKABLE_LEMMA

# Cycle 84 exact threshold checker: tau-folded saturating-screen refinement

## Executive verdict

There is a concrete exact route to the full finite decision. The full census has not been run here (`UNRUN`), but the checker reduction and its no-false-negative proof are complete.

The two decisive reductions are:

1. `17^16-1` is smooth, so the 336 nonzero slot values are converted once to exact discrete logs. The 52.7-billion incidence stream then consists only of 66-bit modular additions.
2. The Cycle 79 complement involution halves the admissible stream to `26,373,783,552` canonical tuples. A 4-bit saturating coarse screen followed by exact refinement replaces Cycle 83's 66 GB Bloom filter or 0.5–0.85 TB external sort.

Recommended exact profile: about 3.2 GiB peak RAM, no required scratch, two half-stream passes. A 4 GiB screen is the safer high-throughput profile.

## Exact theorem used by the checker

Let

```
F = F_17[X]/(X^16 + X^8 + 3),
N = |F^*| = 17^16 - 1 = 48,661,191,875,666,868,480.
```

The factorization is

```
N = 2^8 * 3^2 * 5 * 29 * 18913 * 41761 * 184417.
```

The checker verifies that

```
g = 1 + X
```

is primitive and computes, by deterministic Pohlig–Hellman, the exact exponents

```
e[t,k] = log_g(u_t(k)) mod N,  t=1,...,7, k=0,...,47.
```

For the Cycle 79 involution

```
tau(1,a) = (2,a+6),
tau(2,a) = (1,a+10),
tau(3,a) = (3,a+8),
```

one obtains

```
kappa = 28,612,129,440,766,144,972,
delta = kappa/2 = 14,306,064,720,383,072,486.
```

For a seven-tuple `T`, write

```
E(T) = sum_t e[t,k_t] mod N,
x(T) = E(T) - delta mod N,
q(T) = min(x(T), N-x(T)) in [0,N/2].
```

Let `D` be the canonical half-shell

```
D = {T in P0 : k1 < tau(k1)}.
```

Equivalently, the allowed first-slot keys are

```
{0,...,15,32,...,39}.
```

Then `|D| = |P0|/2 = 26,373,783,552`. If

```
n(q) = #{T in D : q(T)=q},
```

then:

```
0 < q < N/2:  n(q) = m(g^(delta+q)) = m(g^(delta-q));
q = 0:         2 n(q) = m(g^delta);
q = N/2:       2 n(q) = m(g^(delta+N/2)).
```

Therefore

```
max_v m(v) <= 12
```

is equivalent to

```
n(q) <= 12 for every non-self-dual q,
n(0) <= 6,
n(N/2) <= 6.
```

### Proof

`tau` is fixed-point-free on every slot alphabet, preserves `P0`, and sends

```
E(T) -> kappa-E(T),
x(T) -> -x(T).
```

The condition `k1 < tau(k1)` selects exactly one tuple from every two-element `tau`-orbit. For `0<q<N/2`, each tuple orbit contains one tuple of exponent `delta+q` and one of exponent `delta-q`; hence the number of canonical tuple orbits is the multiplicity of either product value. At `q=0` or `N/2`, both members of each tuple orbit have the same product, so the full product multiplicity is twice the canonical count.

## Exact two-pass checker

### Pass 1: saturating screen

Choose a fixed number `B` of coarse buckets. The implementation default is a 3 GiB byte array containing two 4-bit counters per byte:

```
B = 2 * 3 * 2^30 = 6,442,450,944 counters.
```

For each non-self-dual canonical record, compute the deterministic bucket

```
b(q) = floor(H(q) * B / 2^64),
```

where `H` is the fixed SplitMix64 finalizer in the source. Increment the 4-bit bucket counter, saturating at 13. Self-dual keys `0,N/2` are counted exactly and abort at canonical count 7.

After pass 1, compact the counter array in place to one bit per bucket:

```
S[b] = 1 iff the saturated count at b is 13.
```

### Pass 2: exact refinement

Re-enumerate the same canonical stream. Ignore self-dual keys. For a record with key `q`, perform exact counting only when `S[b(q)]=1`. Exact keys are sharded by their top eight bits and counted by the remaining 57 bits. The checker aborts as soon as any exact count reaches 13 and emits 13 normalized witnesses with one common original product.

If the pass completes with no count 13, emit `MMAX_LE_12_CERTIFIED`.

## No-false-negative proof

Let a non-self-dual exact key `q` occur at least 13 times. All occurrences use the same deterministic bucket `b(q)`. Thus pass 1 sends at least 13 increments to that bucket, so its saturated bit is set regardless of any hash collisions. Pass 2 therefore examines every occurrence of `q` and exact-counts the 65-bit key. Its thirteenth occurrence forces a `FAIL` packet.

Conversely, if a bucket is not saturated, its total number of records is at most 12, so no exact key in that bucket can occur 13 times. Hash collisions can only saturate extra buckets and increase pass-2 work; they cannot hide a heavy key.

The parallel nibble update uses a byte-wide compare-and-swap, so no increments can be lost. A resource-cap exit is `RESOURCE_EXHAUSTED_NO_CLAIM`, never `PASS`.

## Encodings

### Field element

For

```
a = a0 + a1 X + ... + a15 X^15,  0 <= ai < 17,
```

define

```
enc_F(a) = sum_i ai 17^i.
```

This is a canonical integer in `[0,17^16-1]`, encoded as nine little-endian bytes.

### Multiplicative exponent

`log_g(a)` is the unique integer in `[0,N-1]`, encoded as nine little-endian bytes; only two bits of the ninth byte are used.

### Folded key

`q in [0,N/2]` is encoded as nine little-endian bytes; only one bit of the ninth byte is used.

### Tuple witness

```
left_id  = (k1*48 + k2)*48 + k3            (17 bits),
right_id = ((k4*48 + k5)*48 + k6)*48 + k7 (23 bits),
pair_id  = (left_id << 23) | right_id      (40 bits).
```

### Optional spill/refinement record, 16 bytes

The deterministic exact shard is

```
shard(q) = q >> 57  in {0,...,255}.
```

Within the shard, an exact record is:

```
bytes 0..7   : q mod 2^57, uint64 little-endian;
bytes 8..12  : pair_id, low 40 bits little-endian;
byte 13      : normalization sign, 0 for x=q and 1 for x=N-q;
bytes 14..15 : zero, reserved for schema version 1.
```

The shard identity plus the low 57 bits reconstructs the exact key. No hash is an equality key.

## Certificates

### PASS

The executable emits at minimum:

```
decision = MMAX_LE_12_CERTIFIED
full_domain = true
folded_records_per_pass = 26373783552
screen_bytes, screen_buckets, saturated_buckets
refined_records, refined_exact_keys, refined_max_count <= 12
selfdual_orbit_counts[0] <= 6
selfdual_orbit_counts[1] <= 6
fixed hash seed
matching pass-1/pass-2 commutative stream checksums
```

A release manifest should also record the source SHA-256, compiler command/version, executable SHA-256, host architecture, and complete stdout JSON.

### FAIL

The executable emits:

```
decision = THIRTEEN_FOLD_PACKET_FOUND
folded_key q
common_product_log e
common_product_coefficients in the degree-16 field basis
13 distinct seven-tuples
per-slot (i,a)
per-slot colors
```

For a non-self-dual key, a canonical tuple with centered exponent `-q` is replaced by its `tau`-mate, so all 13 emitted tuples have exponent `delta+q`. For a self-dual key, seven canonical tuple orbits produce 14 full witnesses; the certificate emits the first 13.

## Verification requirements

Compile:

```
g++ -O3 -std=c++20 -pthread cycle84_mmax12_checker.cpp -o cycle84_mmax12_checker
```

Setup verification:

```
./cycle84_mmax12_checker --setup-only
```

Expected constants:

```
N      = 48661191875666868480
kappa  = 28612129440766144972
delta  = 14306064720383072486
L      = 55296
R      = 5308416
|D|    = 26373783552
```

Deterministic theorem run:

```
./cycle84_mmax12_checker --full --threads 1 --screen-mib 3072 --map-cap 60000000 > cycle84_result.json
```

Parallel execution is mathematically exact; `--threads 1` fixes the first emitted failing packet as well as the verdict.

If the exact-map cap is exceeded, rerun with the 4 GiB screen profile:

```
./cycle84_mmax12_checker --full --threads 1 --screen-mib 4096 --map-cap 10000000
```

or enable the optional 256-shard spill format above. A cap exit carries no mathematical claim.

## Resource estimate

The code changes the work from field multiplication to integer addition:

```
setup: 336 Pohlig-Hellman logs, locally verified in under 0.5 s;
pass 1: 26,373,783,552 folded keys;
pass 2: 26,373,783,552 folded keys;
field multiplications in the large stream: zero.
```

Measured setup RSS in the supplied environment was about 188 MiB. The 3 GiB profile has:

```
pass-1 peak: about 3.2 GiB including side tables;
pass-2 saturated bitset: 0.75 GiB;
uniform-hash expectation: about 2.19 million saturated buckets and
                         about 29.3 million records sent to exact refinement;
expected pass-2 map: roughly 1.5-1.9 GiB with std::unordered_map;
required scratch: zero.
```

The 4 GiB profile expects only about 176,000 saturated buckets and 2.33 million refinement records; peak RAM is about 4.2 GiB.

A local smoke benchmark processed roughly 64 million pair evaluations in 1.3 seconds with four threads, but a full 3–4 GiB random-access run will be memory-latency limited. A conservative execution estimate is 0.5–3 hours on a modern 16–64-core server, and approximately 1–4 hours in deterministic single-thread mode depending on memory latency. These are engineering estimates, not completed full-run measurements.

## Exact next construction

Run the attached executable in full-domain mode. The only accepted terminal outputs are:

```
MMAX_LE_12_CERTIFIED
THIRTEEN_FOLD_PACKET_FOUND
RESOURCE_EXHAUSTED_NO_CLAIM
```

The first two close the Cycle 84 finite wall. The third triggers the 4 GiB profile or exact 256-shard spill; it is not a mathematical result.
