# Cycle 84 exact `m_max = 2` certificate

## Result

For the explicit Cycle 66–84 seven-slot model over

`F_17[X]/(X^16 + X^8 + 3)`, `eta = 6 X^9`, `beta = X + 2`,

on the color shell `P0` with total color `4 mod 16`, the exact conclusions are

- `m_max(beta) = 2`;
- ordered off-diagonal product energy `D = 24`;
- exactly `12` product fibers have size `2`, all remaining fibers have size `1`;
- exact occupancy `Occ(beta) = 52,747,567,092`.

Thus the Cycle84 target `m_max(beta) <= 12` holds with large margin.

## Proof architecture

1. `beta` is verified primitive in the cyclic group of order
   `N = 17^16 - 1 = 48,661,191,875,666,868,480`.
2. All 336 slot values are assigned exact discrete logs and verified by field
   exponentiation.
3. Reduce logs modulo `M=N/3`. Product equality in the field implies equality
   in this quotient, so quotient multiplicity upper-bounds true multiplicity.
4. The Cycle79 involution becomes `x -> kappa-x` modulo `M`. Selecting the 24
   oriented slot-1 keys chooses one tuple from every global tau orbit.
5. The exact 26,373,783,552-tuple oriented census has zero mass in the two
   fixed quotient bins, 30 canonical double bins, no larger bin, folded energy
   `60`, and full projected energy `120`.
6. The order-3 kernel lift checks all 30 double bins. Exactly 6 canonical bins
   are true collisions; tau supplies the partner fiber for each, giving 12
   double fibers and `D=12*2=24`.

## Verification

Lightweight certificate verification, including direct finite-field checking
of all 30 lifted pairs:

```bash
python3 verify_certificate.py
```

Expected decision:

```text
CYCLE84_EXACT_MMAX2_CERTIFICATE_VERIFIED
```

Recompile and rerun the exact projected census:

```bash
g++ -O3 -march=native -fopenmp -D_GLIBCXX_PARALLEL \
  src/tau_fold_full_optimized.cpp -o tau_fold_full_optimized
OMP_NUM_THREADS=16 ./tau_fold_full_optimized 16384 16 > tau_opt.rerun.json
```

Expected decisive fields:

```text
fixed_selected_counts = [0,0]
tau_half_domain_counted = 26373783552
folded_ordered_energy = 60
projected_ordered_energy = 120
full_projected_max_including_fixed = 2
```

Recompile and rerun the kernel lift after the census:

```bash
g++ -O3 -march=native src/tau_duplicate_lift.cpp -o tau_duplicate_lift
./tau_duplicate_lift > tau_lift.rerun.json
```

Expected decisive fields:

```text
true_collision_tau_orbits = 6
true_double_fibers = 12
exact_true_ordered_offdiagonal_energy = 24
exact_true_m_max = 2
exact_true_occupancy = 52747567092
```

The 4096-shard independent repartition output is also included as
`output/tau_full.out`.
