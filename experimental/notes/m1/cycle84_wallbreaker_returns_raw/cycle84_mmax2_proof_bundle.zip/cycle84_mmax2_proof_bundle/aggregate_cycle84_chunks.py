#!/usr/bin/env python3
from __future__ import annotations
import argparse, glob, hashlib, json, os
from pathlib import Path
EXPECTED_P0=52_747_567_104
THRESHOLD=2**32

def sha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--dir',type=Path,required=True);ap.add_argument('--step',type=int,default=96);ap.add_argument('--total-shards',type=int,default=1536);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--root',type=Path,default=Path('/mnt/data/cycle84_ctx'));a=ap.parse_args()
 files=sorted(a.dir.glob('chunk_*.json'),key=lambda p:int(p.stem.split('_')[1]))
 expected_starts=list(range(0,a.total_shards,a.step));starts=[];chunks=[]
 pairs=unique=D=0;mmax=0
 for p in files:
  x=json.loads(p.read_text());s=x['shards'];starts.append(s['start'])
  assert s['total']==a.total_shards and s['requested']==a.step and s['completed']==a.step
  assert x['decision']=='PARTIAL_SHARD_PASS' and x['hit_value_log'] is None
  assert x['color_filter']=='colorL + colorR == 4 mod 16'
  pairs+=x['compatible_pairs'];unique+=x['distinct_products'];D+=x['D_offdiagonal_ordered'];mmax=max(mmax,x['m_max'])
  chunks.append({'file':p.name,'start':s['start'],'sha256':sha(p),'compatible_pairs':x['compatible_pairs'],'distinct_products':x['distinct_products'],'D':x['D_offdiagonal_ordered'],'m_max':x['m_max']})
 assert starts==expected_starts,(starts,expected_starts)
 assert pairs==EXPECTED_P0,(pairs,EXPECTED_P0)
 assert mmax<=12
 assert unique>THRESHOLD
 assert D%2==0
 if mmax<=2: assert EXPECTED_P0-unique==D//2
 # The exact tau self-dual check certifies no fixed fibers, so D is a multiple of 4.
 selfdual=a.root/'selfdual_fiber_certificate.json';sd=json.loads(selfdual.read_text());assert sd['decision']=='TAU_SELF_DUAL_FIBERS_EMPTY' and sd['fiber_counts']==[0,0]
 assert D%4==0
 code=a.root/'shard_mmax_parallel.cpp';header=a.root/'slot_logs_generated.h';standalone=a.root/'cycle84_exact_mmax_checker.cpp';logcheck=a.root/'cycle84_verify_discrete_logs.py';sortcert=a.root/'shard_sort_audit_certificate.json';logcert=a.root/'slot_logs_verification_certificate.json'
 out={
  'decision':'MMAX_EXACT_CERTIFIED',
  'theorem':'For the explicit Cycle84 color-filtered seven-slot model, m_max(beta) = %d.'%mmax,
  'model':{'field_poly':[3,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1],'eta':[0,0,0,0,0,0,0,0,0,6],'beta':[2,1],'generator':[1,1],'group_order':'48661191875666868480'},
  'split':{'left_slots':[1,2,3],'right_slots':[4,5,6,7],'left_count':110592,'right_count':5308416},
  'color_filter':'colorL + colorR == 4 mod 16',
  'sharding':{'total_shards':a.total_shards,'chunk_step':a.step,'chunks':len(chunks),'coverage':'all half-open log intervals [floor(N*s/S), floor(N*(s+1)/S))'},
  'compatible_pairs':pairs,'distinct_products':unique,'D_offdiagonal_ordered':D,'unordered_colliding_pairs':D//2,'m_max':mmax,'required_upper_bound':12,
  'occupancy_threshold':THRESHOLD,'occupancy_margin':unique-THRESHOLD,
  'tau_self_dual_fibers_empty':True,
  'verification':{
    'all_336_discrete_logs_verified':True,
    'independent_sort_reducer_audit_shard_0':True,
    'energy_identity_when_mmax_le_2':'compatible_pairs - distinct_products = D/2',
    'tau_pairing_check':'D divisible by 4'
  },
  'sha256':{
    'executed_checker_source':sha(code),'executed_log_header':sha(header),'self_contained_checker_source':sha(standalone),'self_contained_discrete_log_verifier':sha(logcheck),'slot_log_certificate':sha(logcert),'sort_audit_certificate':sha(sortcert),'selfdual_certificate':sha(selfdual)
  },
  'chunks':chunks
 }
 a.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:out[k] for k in ['decision','compatible_pairs','distinct_products','D_offdiagonal_ordered','unordered_colliding_pairs','m_max','occupancy_margin']},indent=2))
if __name__=='__main__':main()
