// Cycle 84 deterministic ratio-signature PB instance generator.
//
// Builds the exact seven one-slot ratio alphabets in
//   F_17[X]/(X^16+X^8+3), eta=6X^9, beta=X+2,
// computes discrete logs to the primitive generator g=X+1 via
// Pohlig-Hellman on the completely factored group order, and emits:
//   (1) a CSV table of 7*1153 ratio atoms;
//   (2) an OPB feasibility instance for admissible nontrivial signatures
//       q_1...q_7=1, sum delta_t=0 mod 16, support >=5;
//   (3) a JSON arithmetic certificate.
//
// It does not solve the OPB instance.  A proof-producing PB/SAT solver should
// enumerate all models, blocking each one, and return a final UNSAT proof.

#include <array>
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

using u128 = unsigned __int128;

struct F {
    std::array<uint8_t, 16> c{};
    bool operator==(const F& o) const { return c == o.c; }
    bool operator!=(const F& o) const { return c != o.c; }
};

struct Key {
    uint64_t lo{};
    uint16_t hi{};
    bool operator==(const Key& o) const { return lo == o.lo && hi == o.hi; }
    bool operator<(const Key& o) const {
        return hi < o.hi || (hi == o.hi && lo < o.lo);
    }
};

struct KeyHash {
    size_t operator()(const Key& k) const noexcept {
        uint64_t x = k.lo ^ (uint64_t(k.hi) * 0x9e3779b97f4a7c15ULL);
        x ^= x >> 30;
        x *= 0xbf58476d1ce4e5b9ULL;
        x ^= x >> 27;
        x *= 0x94d049bb133111ebULL;
        x ^= x >> 31;
        return size_t(x);
    }
};

static std::string dec(u128 x) {
    if (!x) return "0";
    std::string s;
    while (x) {
        s.push_back(char('0' + unsigned(x % 10)));
        x /= 10;
    }
    std::reverse(s.begin(), s.end());
    return s;
}

static Key pack_key(const F& a) {
    u128 z = 0, m = 1;
    for (int i = 0; i < 16; ++i) {
        z += unsigned(a.c[i]) * m;
        m *= 17;
    }
    return {uint64_t(z), uint16_t(z >> 64)};
}

static F one() {
    F a;
    a.c[0] = 1;
    return a;
}

static F scalar(int x) {
    F a;
    x %= 17;
    if (x < 0) x += 17;
    a.c[0] = uint8_t(x);
    return a;
}

static F subf(const F& a, const F& b) {
    F r;
    for (int i = 0; i < 16; ++i) r.c[i] = uint8_t((a.c[i] + 17 - b.c[i]) % 17);
    return r;
}

static F mul(const F& a, const F& b) {
    int tmp[31]{};
    for (int i = 0; i < 16; ++i) if (a.c[i]) {
        for (int j = 0; j < 16; ++j) if (b.c[j]) {
            tmp[i + j] = (tmp[i + j] + a.c[i] * b.c[j]) % 17;
        }
    }
    // X^16 = -X^8 - 3.
    for (int d = 30; d >= 16; --d) {
        int z = tmp[d] % 17;
        if (!z) continue;
        tmp[d - 8] = (tmp[d - 8] - z) % 17;
        if (tmp[d - 8] < 0) tmp[d - 8] += 17;
        tmp[d - 16] = (tmp[d - 16] - 3 * z) % 17;
        if (tmp[d - 16] < 0) tmp[d - 16] += 17;
    }
    F r;
    for (int i = 0; i < 16; ++i) r.c[i] = uint8_t(tmp[i] % 17);
    return r;
}

static F fpow(F a, u128 e) {
    F r = one();
    while (e) {
        if (e & 1) r = mul(r, a);
        a = mul(a, a);
        e >>= 1;
    }
    return r;
}

static int inv_mod_int(int a, int m) {
    long long t = 0, nt = 1, r = m, nr = a % m;
    while (nr) {
        long long q = r / nr;
        long long tt = t - q * nt; t = nt; nt = tt;
        long long rr = r - q * nr; r = nr; nr = rr;
    }
    if (r != 1) throw std::runtime_error("noninvertible CRT modulus");
    t %= m;
    if (t < 0) t += m;
    return int(t);
}

static int mod_u128(u128 x, int m) {
    return int(x % unsigned(m));
}

static int color_of(int k) {
    static const int S[3] = {15, 9, 12};
    return (S[k / 16] + 8 * ((k % 16) & 1)) & 15;
}

static int tau_of(int k) {
    int i = k / 16 + 1, a = k % 16;
    if (i == 1) return 16 + ((a + 6) & 15);
    if (i == 2) return ((a + 10) & 15);
    return 32 + ((a + 8) & 15);
}

struct Atom {
    int slot{};
    u128 log{};
    int delta{};
    bool nonidentity{};
    bool generic{};  // nontrivial ratio orbit has size 2
    Key ratio_key{};
    std::vector<std::pair<int,int>> pairs;
};

int main(int argc, char** argv) {
    if (argc != 4) {
        std::cerr << "usage: cycle84_ratio_signature_instance ATOMS.csv INSTANCE.opb CERT.json\n";
        return 2;
    }
    const std::string csv_path = argv[1], opb_path = argv[2], cert_path = argv[3];

    u128 Q = 1;
    for (int i = 0; i < 16; ++i) Q *= 17;
    const u128 N = Q - 1;
    const std::vector<int> primes = {2, 3, 5, 29, 18913, 41761, 184417};
    const std::vector<int> pp = {256, 9, 5, 29, 18913, 41761, 184417};

    F eta; eta.c[9] = 6;
    F beta; beta.c[0] = 2; beta.c[1] = 1;
    F xi = mul(beta, beta);
    if (fpow(eta, 16) != scalar(3)) throw std::runtime_error("eta^16 != 3");

    const int E[3][8] = {
        {0,1,2,3,5,11,12,13},
        {0,1,2,3,4,8,9,14},
        {0,1,2,4,5,7,11,14}
    };
    std::array<F, 256> eta_pow;
    eta_pow[0] = one();
    for (int e = 1; e < 256; ++e) eta_pow[e] = mul(eta_pow[e - 1], eta);

    F U[7][48];
    for (int t = 1; t <= 7; ++t) {
        int p3 = 1;
        for (int j = 0; j < t; ++j) p3 = p3 * 3 % 17;
        int inv3 = inv_mod_int(p3, 17);
        for (int i = 0; i < 3; ++i) {
            for (int a = 0; a < 16; ++a) {
                F v = one();
                for (int j = 0; j < 8; ++j) {
                    int b = (a + E[i][j]) & 15;
                    v = mul(v, subf(xi, eta_pow[(2 * t + 16 * b) & 255]));
                }
                U[t - 1][16 * i + a] = mul(scalar(inv3), v);
            }
        }
    }

    // g=X+1, with exact primitive-order checks.
    F g; g.c[0] = 1; g.c[1] = 1;
    for (int p : primes) {
        if (fpow(g, N / unsigned(p)) == one()) {
            throw std::runtime_error("X+1 is not primitive");
        }
    }

    // Pohlig-Hellman lookup tables for each pairwise-coprime prime power.
    std::vector<std::unordered_map<Key,int,KeyHash>> dlog_tables(pp.size());
    for (size_t j = 0; j < pp.size(); ++j) {
        int m = pp[j];
        F h = fpow(g, N / unsigned(m));
        auto& tab = dlog_tables[j];
        tab.reserve(size_t(m * 1.35));
        F cur = one();
        for (int e = 0; e < m; ++e) {
            tab.emplace(pack_key(cur), e);
            cur = mul(cur, h);
        }
        if (int(tab.size()) != m || cur != one()) throw std::runtime_error("bad dlog table");
    }

    auto dlog = [&](const F& x) -> u128 {
        std::vector<int> residues;
        residues.reserve(pp.size());
        for (size_t j = 0; j < pp.size(); ++j) {
            F y = fpow(x, N / unsigned(pp[j]));
            auto it = dlog_tables[j].find(pack_key(y));
            if (it == dlog_tables[j].end()) throw std::runtime_error("Pohlig-Hellman lookup failed");
            residues.push_back(it->second);
        }
        u128 xcrt = 0, mod = 1;
        for (size_t j = 0; j < pp.size(); ++j) {
            int mj = pp[j];
            int rhs = residues[j];
            int cur = mod_u128(xcrt, mj);
            int diff = rhs - cur;
            diff %= mj;
            if (diff < 0) diff += mj;
            int inv = inv_mod_int(mod_u128(mod, mj), mj);
            int step = int((1LL * diff * inv) % mj);
            xcrt += mod * unsigned(step);
            mod *= unsigned(mj);
        }
        if (mod != N || fpow(g, xcrt) != x) throw std::runtime_error("CRT dlog verification failed");
        return xcrt;
    };

    std::array<std::vector<Atom>, 7> atoms;
    const F ONE = one();
    for (int t = 0; t < 7; ++t) {
        std::array<F,48> invU;
        for (int k = 0; k < 48; ++k) invU[k] = fpow(U[t][k], N - 1);

        struct RatioClass { F q; std::vector<std::pair<int,int>> pairs; };
        std::map<Key, RatioClass> classes;
        for (int a = 0; a < 48; ++a) {
            for (int b = 0; b < 48; ++b) {
                F q = mul(U[t][a], invU[b]);
                Key k = pack_key(q);
                auto it = classes.find(k);
                if (it == classes.end()) {
                    RatioClass rc; rc.q = q; rc.pairs.push_back({a,b});
                    classes.emplace(k, std::move(rc));
                } else {
                    it->second.pairs.push_back({a,b});
                }
            }
        }
        if (classes.size() != 1153) throw std::runtime_error("ratio class count != 1153");

        for (auto& [rk, rc] : classes) {
            bool ident = (rc.q == ONE);
            if (ident) {
                if (rc.pairs.size() != 48) throw std::runtime_error("identity fiber !=48");
                for (auto [a,b] : rc.pairs) if (a != b) throw std::runtime_error("identity non-diagonal");
            } else {
                if (rc.pairs.size() != 1 && rc.pairs.size() != 2) throw std::runtime_error("nontrivial ratio fiber >2");
                std::vector<std::pair<int,int>> image;
                for (auto [a,b] : rc.pairs) image.push_back({tau_of(b), tau_of(a)});
                std::sort(image.begin(), image.end());
                auto sorted = rc.pairs;
                std::sort(sorted.begin(), sorted.end());
                if (image != sorted) throw std::runtime_error("ratio fiber not tau orbit");
            }
            int delta = ident ? 0 : ((color_of(rc.pairs[0].first) - color_of(rc.pairs[0].second)) & 15);
            for (auto [a,b] : rc.pairs) {
                if (((color_of(a) - color_of(b)) & 15) != delta) throw std::runtime_error("delta not forced");
            }
            Atom a;
            a.slot = t + 1;
            a.log = dlog(rc.q);
            a.delta = delta;
            a.nonidentity = !ident;
            a.generic = (!ident && rc.pairs.size() == 2);
            a.ratio_key = rk;
            a.pairs = rc.pairs;
            atoms[t].push_back(std::move(a));
        }
        std::sort(atoms[t].begin(), atoms[t].end(), [](const Atom& a, const Atom& b) {
            if (a.log != b.log) return a.log < b.log;
            if (a.delta != b.delta) return a.delta < b.delta;
            return a.ratio_key < b.ratio_key;
        });
        if (atoms[t].size() != 1153 || atoms[t][0].log != 0 || atoms[t][0].nonidentity) {
            throw std::runtime_error("bad sorted atom table");
        }
    }

    std::ofstream csv(csv_path);
    csv << "slot,atom_id,dlog,delta,nonidentity,generic,ratio_key_hi,ratio_key_lo,endpoint_pairs\n";
    for (int t = 0; t < 7; ++t) {
        for (size_t j = 0; j < atoms[t].size(); ++j) {
            const Atom& a = atoms[t][j];
            csv << (t+1) << ',' << j << ',' << dec(a.log) << ',' << a.delta << ','
                << int(a.nonidentity) << ',' << int(a.generic) << ','
                << a.ratio_key.hi << ',' << a.ratio_key.lo << ",\"";
            for (size_t z = 0; z < a.pairs.size(); ++z) {
                if (z) csv << ';';
                csv << a.pairs[z].first << ':' << a.pairs[z].second;
            }
            csv << "\"\n";
        }
    }
    csv.close();

    // OPB model. x_t_j is one-hot. k0,k1,k2 encode the carry in [0,6]
    // for the group congruence; z0,z1,z2 encode the color carry in [0,6].
    std::ofstream opb(opb_path);
    opb << "* cycle84 ratio-signature feasibility instance\n";
    opb << "* N=" << dec(N) << "; primitive g=X+1; support>=5\n";
    for (int t = 0; t < 7; ++t) {
        for (size_t j = 0; j < atoms[t].size(); ++j) opb << "+1 x" << (t+1) << "_" << j << ' ';
        opb << "= 1 ;\n";
    }
    // Support >=5.
    for (int t = 0; t < 7; ++t) for (size_t j = 0; j < atoms[t].size(); ++j) {
        if (atoms[t][j].nonidentity) opb << "+1 x" << (t+1) << "_" << j << ' ';
    }
    opb << ">= 5 ;\n";
    // Product dlog sum = N*k, k in 0..6.
    for (int t = 0; t < 7; ++t) for (size_t j = 0; j < atoms[t].size(); ++j) {
        if (atoms[t][j].log) opb << '+' << dec(atoms[t][j].log) << " x" << (t+1) << "_" << j << ' ';
    }
    opb << '-' << dec(N) << " k0 -" << dec(2*N) << " k1 -" << dec(4*N) << " k2 = 0 ;\n";
    opb << "+1 k0 +1 k1 +1 k2 <= 2 ;\n"; // forbid carry 7
    // Color-difference sum = 16*z, z in 0..6.
    for (int t = 0; t < 7; ++t) for (size_t j = 0; j < atoms[t].size(); ++j) {
        if (atoms[t][j].delta) opb << '+' << atoms[t][j].delta << " x" << (t+1) << "_" << j << ' ';
    }
    opb << "-16 z0 -32 z1 -64 z2 = 0 ;\n";
    opb << "+1 z0 +1 z1 +1 z2 <= 2 ;\n"; // forbid carry 7
    opb.close();

    std::ofstream cert(cert_path);
    cert << "{\n";
    cert << "  \"decision\": \"RATIO_SIGNATURE_INSTANCE_EMITTED_UNSOLVED\",\n";
    cert << "  \"field_order_minus_one\": \"" << dec(N) << "\",\n";
    cert << "  \"factorization\": \"2^8 * 3^2 * 5 * 29 * 18913 * 41761 * 184417\",\n";
    cert << "  \"primitive_generator\": [1,1],\n";
    cert << "  \"primitive_generator_order_checks\": true,\n";
    cert << "  \"pohlig_hellman_prime_powers\": [256,9,5,29,18913,41761,184417],\n";
    cert << "  \"slots\": 7,\n";
    cert << "  \"ratio_atoms_per_slot\": 1153,\n";
    cert << "  \"identity_atoms_per_slot\": 1,\n";
    cert << "  \"singleton_nonidentity_atoms_per_slot\": 48,\n";
    cert << "  \"generic_nonidentity_atoms_per_slot\": 1104,\n";
    cert << "  \"constraints\": [\"one_hot_per_slot\", \"support_ge_5\", \"sum_dlog_eq_0_mod_N\", \"sum_delta_eq_0_mod_16\"],\n";
    cert << "  \"solver_status\": \"UNRUN\"\n";
    cert << "}\n";
    cert.close();
    return 0;
}
